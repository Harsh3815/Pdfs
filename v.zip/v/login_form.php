<?php
@include 'config.php';
$query=" SELECT * FROM user_form";
$data = mysqli_query($conn,$query );
$total =mysqli_num_rows($data);
@$admin=$result['email'];
@$admin_pass=$result['password'];
@$email=$_POST['email'];
@$pass=$_POST['password'];
while($result=mysqli_fetch_assoc($data))
{
    
    if($email=='admin@gmail.com'&&$pass=='admin')
{
   session_start();
   $_SESSION['username']=true;
   $_SESSION['username']='admin';
   header("location:admin/admin.html");
}
elseif(@$email==@$result['email']&&@$pass==@$result['password'])
{
  $_SESSION['loggedin']=true;
   $_SESSION['username']=$email;
   header("location:cart.php");
}

}
?>
<!DOCTYPE html>
<html >
<head>
   
   <title>login form</title>
   <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #d9eafd;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    form {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px #ff9999;
    }
    input {
      display: block;
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #e60073;
      color: white;
      border: none;
      padding: 10px;
      cursor: pointer;
    }
    
  </style>
   

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>login now</h3>
      <input type="email" name="email" required placeholder="enter your email"><br>
      <input type="password" name="password" required placeholder="enter your password"><br>
      <input type="submit" name="submit" value="login now" class="form-btn">
      <p>don't have an account? <a href="register_form.php">register now</a></p>
   </form>

</div>

</body>
</html>