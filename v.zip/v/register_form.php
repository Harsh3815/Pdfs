<?php

@include 'config.php';

if(isset($_POST['submit'])){

   $name =  $_POST['name'];
   $email = $_POST['email'];
   $pass =$_POST['password'];
   $cpass =$_POST['cpassword'];
  // $user_type = $_POST['user_type'];

   

      if($pass != $cpass){
         $error[] = 'password not matched!';
        // echo $error;
      }else{
         $insert = "INSERT INTO user_form(name, email, password,cpassword) VALUES('$name','$email','$pass','$cpass')";
         mysqli_query($conn,$insert);
         header('location:login_form.php');
      }
   

};


?>

<!DOCTYPE html>
<html>
<head>
   
   <title>register form</title>
   <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #d9eafd ;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    form {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px #ff9999;
    }
    input {
      display: block;
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #e60073;
      color: white;
      border: none;
      padding: 10px;
      cursor: pointer;
    }
    table
    {
      border: 5px solid #ccc;
      border-radius: 10px;
      height: 75vh;
      width: 75vh;
      padding: 20px;
      background-color: #f0f7ffff;
    }
  </style>
  

</head>
<body>
   
<div class="form-container">  
      <center>
<table >
   <form action="" method="post">
      <h3>register now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?><tr ><td>enter name</td><td><input type="text" name="name" required placeholder="enter your name"></td></tr>
      <tr><td>enter email</td><td> <input type="email" name="email" required placeholder="enter your email"></td></tr>
     <tr><td>enter password</td><td><input type="password" name="password" required placeholder="enter your password"></td></tr>
      <tr><td>enter conformpassword</td><td><input type="password" name="cpassword" required placeholder="confirm your password"></td></tr>
      <tr><td></td><td><input type="submit" name="submit" value="register now" class="form-btn"></td></tr>
     <tr><td>already have an account?</td><td><a href="login_form.php">login now</a></td></tr>
      
       
   </form>

</div>
</table>
</center>
</body>
</html>