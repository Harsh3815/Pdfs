﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    static string opr;
    static double no;
    static double ans;
    static int i = 0;
    static int j = 0;
    static int k = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void seven_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = seven.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + seven.Text;

        }
       // txtDisplay.Text += seven.Text;
    }

    protected void eight_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = eight.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + eight.Text;

        }
        //txtDisplay.Text += eight.Text;

    }

    protected void nine_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = nine.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + nine.Text;

        }
        //txtDisplay.Text += nine.Text;

    }

    protected void four_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = zero.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + four.Text;

        }
        //txtDisplay.Text += four.Text;

    }

    protected void five_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = zero.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + five.Text;

        }
        //txtDisplay.Text += five.Text;

    }

    protected void six_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = six.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + six.Text;

        }
        //txtDisplay.Text += six.Text;

    }

    protected void one_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = one.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + one.Text;

        }
        //txtDisplay.Text += one.Text;

    }

    protected void two_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = two.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + two.Text;

        }
        //txtDisplay.Text += two.Text;

    }

    protected void three_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = three.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + three.Text;

        }
        //txtDisplay.Text += three.Text;

    }

    protected void zero_Click(object sender, EventArgs e)
    {
        if (opr == "=")
        {
            txtDisplay.Text = "";
            txtDisplay.Text = zero.Text;
            opr = "";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + zero.Text;

        }

    }


    protected void mul_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else if (i == 0)
        {
            no = 1;
            opr = "*";
            no = Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
            i++;
        }
        else
        {
            opr = "*";
            no *= Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";

        }

    }

    protected void sub_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else if (k == 0 && no == 0)
        {
            k = Convert.ToInt32(txtDisplay.Text);
            opr = "-";
            no = Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
            no = k;
            k++;
        }
        else
        {
            opr = "-";
            no -= Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
        }

    }

    protected void sum_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            opr = "+";
            no += Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
        }

    }

    protected void div_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else if (j == 0)
        {

            opr = "/";
            no = Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
            j++;
        }
        else
        {
            opr = "/";
            no /= Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = "";
        }

    }

    protected void equal_Click(object sender, EventArgs e)
    {
        if (opr == "+")
        {
            ans = no + Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = ans.ToString();
        }
        else if (opr == "-")
        {
            ans = no - Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = ans.ToString();
        }
        else if (opr == "*")
        {
            ans = no * Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = ans.ToString();
        }
        else if (opr == "/")
        {
            if (txtDisplay.Text == "0")
            {
                txtDisplay.Text = "cannot diveded by zero";
            }
            else
            {
                ans = no / Convert.ToDouble(txtDisplay.Text);
                txtDisplay.Text = ans.ToString();
            }
        }
        opr = "=";
    }



    protected void CE_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = "";
    }

    protected void dot_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text.Contains("."))
        {
            return;
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text + ".";
        }
    }



    protected void back_Click(object sender, EventArgs e)
    {
        int a = txtDisplay.Text.Length;
        if (a == 0)
        {
            txtDisplay.Text = "empty";
        }
        else
        {
            txtDisplay.Text = txtDisplay.Text.Remove(txtDisplay.Text.Length - 1, 1);

        }
    }

    protected void sqrt_Click(object sender, EventArgs e)
    {

    }

    protected void C_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = "";
        ans = 0;
        no = 0;
        i = 0;
        j = 0;
        k = 0;
    }



    protected void sqrtvar_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            no = Convert.ToDouble(txtDisplay.Text);
            ans = Math.Sqrt(no);
            txtDisplay.Text = ans.ToString();
            opr = "=";
        }
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        seven.Text = txtDisplay.Text;
    }



    protected void B_pm_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            no = Convert.ToDouble(txtDisplay.Text);
            ans = no;
            if (ans > 0)
            {
                ans = -Math.Abs(no);
            }
            else
            {
                ans = Math.Abs(no);
            }
            txtDisplay.Text = ans.ToString();
        }
    }

    protected void per_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            ans = no * Convert.ToDouble(txtDisplay.Text) / 100;
            txtDisplay.Text = ans.ToString();
            ans = 0;
        }
    }

    protected void mp_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            ans = no * Convert.ToDouble(txtDisplay.Text) / 100;
            txtDisplay.Text = ans.ToString();
            ans = 0;
        }
    }

    protected void mr_Click(object sender, EventArgs e)
    {
        txtDisplay.Text = no.ToString();
    }

    protected void mc_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            no = 0;
            txtDisplay.Text = "";

        }
    }

    protected void ms_Click(object sender, EventArgs e)
    {

        if (txtDisplay.Text == "")
        {
        }
        else
        {
            no = Convert.ToDouble(txtDisplay.Text);

        }
    }

    protected void box_Click(object sender, EventArgs e)
    {
        if (txtDisplay.Text == "")
        {
        }
        else
        {
            ans = 1 / Convert.ToDouble(txtDisplay.Text);
            txtDisplay.Text = ans.ToString();
        }
    }
}