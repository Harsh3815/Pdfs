﻿using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

  
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e) { M1.Text = CheckBox1.Text; }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e) { M2.Text = CheckBox2.Text; }
    protected void CheckBox3_CheckedChanged(object sender, EventArgs e) { M3.Text = CheckBox3.Text; }

    protected void CheckBox4_CheckedChanged(object sender, EventArgs e) { M1.Text = CheckBox4.Text; }
    protected void CheckBox5_CheckedChanged(object sender, EventArgs e) { M2.Text = CheckBox5.Text; }
    protected void CheckBox6_CheckedChanged(object sender, EventArgs e) { M3.Text = CheckBox6.Text; }

    protected void CheckBox7_CheckedChanged(object sender, EventArgs e) { M1.Text = CheckBox7.Text; }
    protected void CheckBox8_CheckedChanged(object sender, EventArgs e) { M2.Text = CheckBox8.Text; }
    protected void CheckBox9_CheckedChanged(object sender, EventArgs e) { M3.Text = CheckBox9.Text; }


    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox1.Visible = CheckBox2.Visible = CheckBox3.Visible = true;
        CheckBox4.Visible = CheckBox5.Visible = CheckBox6.Visible = false;
        CheckBox7.Visible = CheckBox8.Visible = CheckBox9.Visible = false;
    }

    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox1.Visible = CheckBox2.Visible = CheckBox3.Visible = false;
        CheckBox4.Visible = CheckBox5.Visible = CheckBox6.Visible = true;
        CheckBox7.Visible = CheckBox8.Visible = CheckBox9.Visible = false;
    }

    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox1.Visible = CheckBox2.Visible = CheckBox3.Visible = false;
        CheckBox4.Visible = CheckBox5.Visible = CheckBox6.Visible = false;
        CheckBox7.Visible = CheckBox8.Visible = CheckBox9.Visible = true;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        float a = float.Parse(MARK1.Text);
        float b = float.Parse(MARK2.Text);
        float c = float.Parse(MARK3.Text);

        float total = a + b + c;
        float average = total / 3;

        string failedSubjects = "";
        if (a < 28) failedSubjects += M1.Text + " ";
        if (b < 28) failedSubjects += M2.Text + " ";
        if (c < 28) failedSubjects += M3.Text + " ";

        string status = (failedSubjects == "")
            ? "PASSED ALL SUBJECTS"
            : "FAILED in: " + failedSubjects;

        string gender = RadioButton4.Checked ? "Male" : "Female";

       
        finalMarksheet.Text =
            "<div style='width:600px;padding:20px;border:2px solid black;border-radius:10px;font-size:18px;background:#f7f7f7'>" +

            "<h2 style='text-align:center;'><b>STUDENT MARKSHEET</b></h2><hr>" +

            "<b>Name:</b> " + ENAME.Text + "<br>" +
            "<b>Mobile:</b> " + ENUM.Text + "<br>" +
            "<b>Address:</b> " + ADD.Text + "<br>" +
            "<b>Gender:</b> " + gender + "<br><hr>" +

            "<b>Subject 1:</b> " + M1.Text + " → " + MARK1.Text + "<br>" +
            "<b>Subject 2:</b> " + M2.Text + " → " + MARK2.Text + "<br>" +
            "<b>Subject 3:</b> " + M3.Text + " → " + MARK3.Text + "<br><hr>" +

            "<b>Total Marks:</b> " + total + "<br>" +
            "<b>Average:</b> " + average + "<br>" +
            "<b>Result:</b> " + status + "<br>" +

            "</div>";
    }
}
