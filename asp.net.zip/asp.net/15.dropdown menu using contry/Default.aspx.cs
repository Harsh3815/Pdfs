﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            country.Items.Add("select country");
            country.Items.Add("INDIA");
            country.Items.Add("U.S.A");

        }


    }

    protected void country_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (country.Text=="INDIA")
        {
            state.Items.Clear();
            state.Items.Add("select state");
            state.Items.Add("Gujarat");
            state.Items.Add("Delhi");

        }

        if (country.Text == "U.S.A")
        {
            state.Items.Clear();
            state.Items.Add("select state");
            state.Items.Add("california");
            state.Items.Add("New York");

        }

    }

    protected void state_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (state.Text == "Gujarat")
        {
            city.Items.Clear();
            city.Items.Add("select state");
            city.Items.Add("rajkot");
            city.Items.Add("jamanger");

        }

        if (country.Text == "Delhi")
        {
            state.Items.Clear();
            state.Items.Add("select state");
            state.Items.Add("Indraprastha");
            state.Items.Add("siri");

        }

        if (state.Text == "california")
        {
            city.Items.Clear();
            city.Items.Add("select state");
            city.Items.Add("San Francisco");
            city.Items.Add("Sacramento");

        }

        if (country.Text == "New York")
        {
            state.Items.Clear();
            state.Items.Add("select state");
            state.Items.Add("The Bronx");
            state.Items.Add("Queens");

        }

    }

    protected void city_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label4.Visible = true;
        Label4.Text = "country:"+country.Text+ "\n state :"+ state.Text+"\n city:" +city.Text;
    }
}