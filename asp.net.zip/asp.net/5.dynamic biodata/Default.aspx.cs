﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnShow_Click(object sender, EventArgs e)
    {

        Response.Write("<p>Full Name: " + TextBox1.Text + "<br /></p>");
        Response.Write("<p>Mobile No: " + TextBox2.Text + "<br /></p>");
        Response.Write("<p>Address: " + TextBox3.Text + "<br /></p>");
        Response.Write("<p>Father Name: " + TextBox4.Text + "<br /></p>");
        Response.Write("<p>Mother Name: " + TextBox5.Text + "<br /></p>");
        Response.Write("<p>Hobbies: " + TextBox6.Text + "<br /></p>");
        Response.Write("<p>Qualification: " + TextBox7.Text + "<br /></p>");
        Response.Write("<p>Email Address: " + TextBox8.Text + "<br /></p>");

    }
}
