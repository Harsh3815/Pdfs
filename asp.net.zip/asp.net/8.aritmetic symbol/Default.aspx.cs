﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int a = int.Parse(TextBox1.Text);
        int b = int.Parse(TextBox2.Text);
        string op = TextBox3.Text;

        if (op == "+") TextBox3.Text = "Answer = " + (a + b);
        else if (op == "-") TextBox3.Text = "Answer = " + (a - b);
        else if (op == "*") TextBox3.Text = "Answer = " + (a * b);
        else if (op == "/") TextBox3.Text = "Answer = " + (a / b);

    }

}
