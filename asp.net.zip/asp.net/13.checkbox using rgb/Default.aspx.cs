﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ColorChanged(object sender, EventArgs e)
    {
        int r = checkRed.Checked ? 255 : 0;
        int g = checkGreen.Checked ? 255 : 0;
        int b = checkBlue.Checked ? 255 : 0;

  
        if (checkRed.Checked && checkGreen.Checked && checkBlue.Checked)
        {
            abc.Style["background-color"] = "#222"; 
            abc.Style["color"] = "white";           
            return;
        }

 
        string rgb = string.Format("rgb({0},{1},{2})", r, g, b);

        abc.Style["background-color"] = rgb;
        abc.Style["color"] = "black";
    }
}
