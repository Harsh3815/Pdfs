﻿using System;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-DSFP3Q6\SQLEXPRESS;Initial Catalog=reg;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1.DataBind();
        }
    }

    // INSERT (used by Submit)
    private void InsertData()
    {
        // gender validation
        if (rblGender.SelectedIndex == -1)
        {
            // Gender select nathi karelu to insert na thay
            return;
        }

        cn.Open();

        SqlCommand cmd = new SqlCommand(
            "INSERT INTO prog (name,email,address,city,gender,username,password) VALUES ('" + txtName.Text + "','"
            + txtEmail.Text + "','"
            + txtAddress.Text + "','"
            + txtCity.Text + "','"
            + rblGender.SelectedValue + "','"
            + txtUname.Text + "','"
            + txtPassword.Text + "')", cn);

        cmd.ExecuteNonQuery();
        cn.Close();
    }

    // SUBMIT
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // insert
        InsertData();

        // grid refresh
        GridView1.DataBind();

        // SUCCESS BUTTON CHANGE
        btnSubmit.Text = "Success";
        btnSubmit.CssClass = "btn btn-success";
        btnSubmit.Enabled = false;

        // Clear form
        txtName.Text = "";
        txtEmail.Text = "";
        txtAddress.Text = "";
        txtCity.Text = "";
        txtUname.Text = "";
        txtPassword.Text = "";
        rblGender.ClearSelection();
    }   

    // DELETE (username wise)
    protected void btndelete_Click(object sender, EventArgs e)
    {
        cn.Open();

        SqlCommand cmd = new SqlCommand(
            "DELETE FROM prog WHERE username='" + txtUname.Text + "'", cn);

        cmd.ExecuteNonQuery();
        cn.Close();

        GridView1.DataBind();
    }

    // UPDATE (username wise)
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        // gender optional: if not selected then blank set thase, so check
        string g = "";
        if (rblGender.SelectedIndex != -1)
            g = rblGender.SelectedValue;

        cn.Open();

        SqlCommand cmd = new SqlCommand(
            "UPDATE prog SET name='" + txtName.Text + "',email='" + txtEmail.Text + "',address='" + txtAddress.Text +
            "',city='" + txtCity.Text + "',gender='" + g + "',password='" + txtPassword.Text +
            "' WHERE username='" + txtUname.Text + "'", cn);

        cmd.ExecuteNonQuery();
        cn.Close();

        GridView1.DataBind();
    }

    // VIEW
    protected void btnview_Click(object sender, EventArgs e)
    {
        GridView1.DataBind();
    }
}
