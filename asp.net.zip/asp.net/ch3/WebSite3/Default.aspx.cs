﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-DSFP3Q6\SQLEXPRESS;Initial Catalog=reg;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    // ✅ Disconnected Bind
    private void BindGrid()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT id,name,email,address,city,gender,username,password FROM prog ORDER BY id DESC", cn);
        DataTable dt = new DataTable();
        da.Fill(dt);

        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    private void ClearForm()
    {
        txtId.Text = "";
        txtName.Text = "";
        txtEmail.Text = "";
        txtAddress.Text = "";
        txtCity.Text = "";
        txtUname.Text = "";
        txtPassword.Text = "";
        rblGender.ClearSelection();

        btnSubmit.Enabled = true;
        btnSubmit.Text = "Submit";
        btnSubmit.CssClass = "btn btn-success";
    }

    // ✅ INSERT (Disconnected)
    private void InsertDisconnected()
    {
        if (rblGender.SelectedIndex == -1) return;

        SqlDataAdapter da = new SqlDataAdapter("SELECT id,name,email,address,city,gender,username,password FROM prog", cn);
        da.MissingSchemaAction = MissingSchemaAction.AddWithKey;  // ✅ key info

        DataTable dt = new DataTable();
        da.Fill(dt);

        SqlCommandBuilder cb = new SqlCommandBuilder(da);

        DataRow dr = dt.NewRow();
        dr["name"] = txtName.Text;
        dr["email"] = txtEmail.Text;
        dr["address"] = txtAddress.Text;
        dr["city"] = txtCity.Text;
        dr["gender"] = rblGender.SelectedValue;
        dr["username"] = txtUname.Text;
        dr["password"] = txtPassword.Text;

        dt.Rows.Add(dr);
        da.Update(dt);
    }

    // ✅ UPDATE by ID (Disconnected)
    private void UpdateDisconnected()
    {
        if (txtId.Text.Trim() == "") return;
        if (rblGender.SelectedIndex == -1) return;

        SqlDataAdapter da = new SqlDataAdapter(
            "SELECT id,name,email,address,city,gender,username,password FROM prog WHERE id=" + txtId.Text, cn);

        da.MissingSchemaAction = MissingSchemaAction.AddWithKey;

        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count == 0) return;

        SqlCommandBuilder cb = new SqlCommandBuilder(da);

        dt.Rows[0]["name"] = txtName.Text;
        dt.Rows[0]["email"] = txtEmail.Text;
        dt.Rows[0]["address"] = txtAddress.Text;
        dt.Rows[0]["city"] = txtCity.Text;
        dt.Rows[0]["gender"] = rblGender.SelectedValue;
        dt.Rows[0]["username"] = txtUname.Text;
        dt.Rows[0]["password"] = txtPassword.Text;

        da.Update(dt);
    }

    // ✅ DELETE by ID (Disconnected)  **FIXED**
    private void DeleteDisconnected()
    {
        if (txtId.Text.Trim() == "") return;

        SqlDataAdapter da = new SqlDataAdapter(
            "SELECT id,name,email,address,city,gender,username,password FROM prog WHERE id=" + txtId.Text, cn);

        da.MissingSchemaAction = MissingSchemaAction.AddWithKey;

        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count == 0) return;

        SqlCommandBuilder cb = new SqlCommandBuilder(da);

        dt.Rows[0].Delete();
        da.Update(dt);
    }

    // ================= BUTTONS =================

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        InsertDisconnected();
        BindGrid();

        btnSubmit.Text = "Success";
        btnSubmit.CssClass = "btn btn-success";
        btnSubmit.Enabled = false;

        ClearForm();
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        UpdateDisconnected();
        BindGrid();
        ClearForm();
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        DeleteDisconnected();
        BindGrid();
        ClearForm();
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        BindGrid();
    }

    // ✅ Grid Select -> Fill Form + set txtId
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;

        // Select button hova thi cell[0] select, so id = cell[1]
        txtId.Text = row.Cells[1].Text;
        txtName.Text = row.Cells[2].Text;
        txtEmail.Text = row.Cells[3].Text;
        txtAddress.Text = row.Cells[4].Text;
        txtCity.Text = row.Cells[5].Text;

        string gender = row.Cells[6].Text;
        rblGender.ClearSelection();
        if (gender == "Male") rblGender.Items[0].Selected = true;
        if (gender == "Female") rblGender.Items[1].Selected = true;

        txtUname.Text = row.Cells[7].Text;
        txtPassword.Text = row.Cells[8].Text;
    }
}
