﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(
        @"Data Source=DESKTOP-DSFP3Q6\SQLEXPRESS;Initial Catalog=reg;Integrated Security=True"
    );

    protected void Page_Load(object sender, EventArgs e)
    {
        // empty
    }

    // Button 1 → Database data GridView1 માં show
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlDataAdapter da = new SqlDataAdapter("select * from prog", cn);

        DataTable dt = new DataTable();
        da.Fill(dt);

        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    // Button 2 → Database data GridView2 માં + XML file create
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlDataAdapter da = new SqlDataAdapter("select * from prog", cn);

        DataTable dt = new DataTable();
        dt.TableName = "prog";   // ✅ VERY IMPORTANT LINE

        da.Fill(dt);

        dt.WriteXml(Server.MapPath("bscit.xml"));

        GridView2.DataSource = dt;
        GridView2.DataBind();
    }

}

