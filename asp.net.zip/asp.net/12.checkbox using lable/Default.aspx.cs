﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Text = CheckBox1.Text;
    }

    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Text = CheckBox2.Text;
    }

    protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Text = CheckBox3.Text;
    }
}