﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            ListBox1.Items.Add("C lang.");
            ListBox1.Items.Add("c++");
            ListBox1.Items.Add("Html");
            ListBox1.Items.Add("Java");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        for(int i = ListBox1.Items.Count -1; i >= 0; i--)
        {
            if (ListBox1.Items[i].Selected)
            {
                ListBox2.Items.Add(ListBox1.Items[i]);
                ListBox1.Items.RemoveAt(i);
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        foreach (ListItem item in ListBox1.Items)
        {
            ListBox2.Items.Add(item);
        }
        ListBox1.Items.Clear();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        for(int i=ListBox2.Items.Count -1; i>=0;i--)
        {
            if(ListBox2.Items[i].Selected)
            {
                ListBox1.Items.Add(ListBox2.Items[i]);
                ListBox2.Items.RemoveAt(i);
            }
        }
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        foreach (ListItem item in ListBox2.Items)
        {
            ListBox1.Items.Add(item);
        }
        ListBox2.Items.Clear();

    }
}