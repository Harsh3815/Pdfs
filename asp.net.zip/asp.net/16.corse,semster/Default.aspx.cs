﻿using System;
using System.Web.UI;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            stream.Items.Add("Select Stream");
            stream.Items.Add("Commerce");
            stream.Items.Add("Science");
        }
    }

    protected void stream_SelectedIndexChanged(object sender, EventArgs e)
    {
        course.Items.Clear();
        sem.Items.Clear();
        subject.Items.Clear();

        if (stream.Text == "Commerce")
        {
            course.Items.Add("Select Course");
            course.Items.Add("BCA");
            course.Items.Add("BBA");
        }
        else if (stream.Text == "Science")
        {
            course.Items.Add("Select Course");
            course.Items.Add("BSC");
            course.Items.Add("PGDCA");
        }
    }

    protected void course_SelectedIndexChanged(object sender, EventArgs e)
    {
        sem.Items.Clear();
        subject.Items.Clear();

     
        if (course.Text == "BCA")
        {
            sem.Items.Add("Select Semester");
            sem.Items.Add("BCA-1");
            sem.Items.Add("BCA-2");
            sem.Items.Add("BCA-3");
            sem.Items.Add("BCA-4");
            sem.Items.Add("BCA-5");
            sem.Items.Add("BCA-6");
        }

        if (course.Text == "BBA")
        {
            sem.Items.Add("Select Semester");
            sem.Items.Add("BBA-1");
            sem.Items.Add("BBA-2");
            sem.Items.Add("BBA-3");
            sem.Items.Add("BBA-4");
            sem.Items.Add("BBA-5");
            sem.Items.Add("BBA-6");
        }

        if (course.Text == "BSC")
        {
            sem.Items.Add("Select Semester");
            sem.Items.Add("BSC-1");
            sem.Items.Add("BSC-2");
            sem.Items.Add("BSC-3");
            sem.Items.Add("BSC-4");
            sem.Items.Add("BSC-5");
            sem.Items.Add("BSC-6");
        }

        if (course.Text == "PGDCA")
        {
            sem.Items.Add("Select Semester");
            sem.Items.Add("PG-1");
            sem.Items.Add("PG-2");
            sem.Items.Add("PG-3");
            sem.Items.Add("PG-4");
            sem.Items.Add("PG-5");
            sem.Items.Add("PG-6");
        }
    }

    protected void sem_SelectedIndexChanged(object sender, EventArgs e)
    {
        subject.Items.Clear();

    
        if (sem.Text == "BCA-1")
        {
            subject.Items.Add("C Language");
            subject.Items.Add("Computer Fundamentals");
            subject.Items.Add("HTML");
        }

        if (sem.Text == "BCA-2")
        {
            subject.Items.Add("COA");
            subject.Items.Add("PHP");
            subject.Items.Add("SAD");
        }

        if (sem.Text == "BCA-3")
        {
            subject.Items.Add("SQL");
            subject.Items.Add("WordPress");
            subject.Items.Add("C++");
        }

        if (sem.Text == "BCA-4")
        {
            subject.Items.Add("Java");
            subject.Items.Add("C#");
            subject.Items.Add("Operating System");
        }

        if (sem.Text == "BCA-5")
        {
            subject.Items.Add("J2EE");
            subject.Items.Add("Python");
            subject.Items.Add("Cyber Security");
        }

        if (sem.Text == "BCA-6")
        {
            subject.Items.Add("ASP.NET");
            subject.Items.Add("Machine Learning");
            subject.Items.Add("Android");
        }

    
        if (sem.Text == "BBA-1")
        {
            subject.Items.Add("Financial Accounting");
            subject.Items.Add("Human Values");
            subject.Items.Add("Microeconomics");
        }

        if (sem.Text == "BBA-2")
        {
            subject.Items.Add("Financial Management");
            subject.Items.Add("Community Development");
            subject.Items.Add("Introduction to Python");
        }

        if (sem.Text == "BBA-3")
        {
            subject.Items.Add("Operations Management");
            subject.Items.Add("Marketing Management");
            subject.Items.Add("Business Environment");
        }

        if (sem.Text == "BBA-4")
        {
            subject.Items.Add("E-Commerce");
            subject.Items.Add("Supply Chain Management");
            subject.Items.Add("Design Thinking");
        }

        if (sem.Text == "BBA-5")
        {
            subject.Items.Add("HRM");
            subject.Items.Add("Finance");
            subject.Items.Add("Marketing");
        }

        if (sem.Text == "BBA-6")
        {
            subject.Items.Add("Data Analytics");
            subject.Items.Add("Retail Management");
            subject.Items.Add("Digital Marketing");
        }

    
        if (sem.Text == "BSC-1")
        {
            subject.Items.Add("Physics");
            subject.Items.Add("Chemistry");
            subject.Items.Add("Mathematics");
         }

        if (sem.Text == "BSC-2")
        {
            subject.Items.Add("Biology");
            subject.Items.Add("Zoology");
            subject.Items.Add("Statistics");
        }

        if (sem.Text == "BSC-3")
        {
            subject.Items.Add("CS");
            subject.Items.Add("IT");
            subject.Items.Add("Data Science");
        }

        if (sem.Text == "BSC-4")
        {
            subject.Items.Add("AI");
            subject.Items.Add("Microbiology");
            subject.Items.Add("Software Engineering");
        }

        if (sem.Text == "BSC-5")
        {
            subject.Items.Add("Biotechnology");
            subject.Items.Add("Genetics");
            subject.Items.Add("Biochemistry");
        }

        if (sem.Text == "BSC-6")
        {
            subject.Items.Add("Geography");
            subject.Items.Add("Oceanography");
            subject.Items.Add("Meteorology");
        }

     
        if (sem.Text == "PG-1")
        {
            subject.Items.Add("Computer Basics");
            subject.Items.Add("C Programming");
        }

        if (sem.Text == "PG-2")
        {
            subject.Items.Add("Web Designing");
            subject.Items.Add("DBMS");
        }

        if (sem.Text == "PG-3")
        {
            subject.Items.Add("Java");
            subject.Items.Add("Operating System");
        }

        if (sem.Text == "PG-4")
        {
            subject.Items.Add("Python");
            subject.Items.Add("Data Structures");
        }

        if (sem.Text == "PG-5")
        {
            subject.Items.Add("Cloud Computing");
            subject.Items.Add("Networking");
        }

        if (sem.Text == "PG-6")
        {
            subject.Items.Add("AI");
            subject.Items.Add("Big Data");
        }
    }

    protected void subject_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label5.Visible = true;
        Label5.Text = "Stream : " + stream.Text +
                      "<br>Course : " + course.Text +
                      "<br>Semester : " + sem.Text +
                      "<br>Subject : " + subject.Text;
    }
}
 x